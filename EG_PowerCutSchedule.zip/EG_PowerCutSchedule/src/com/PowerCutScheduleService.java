package com;

import model.PowerCutSchedule;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
import org.jsoup.*;
import org.jsoup.parser.*;
import org.jsoup.nodes.Document;

@Path("/PowerCutSchedule")
public class PowerCutScheduleService {
	PowerCutSchedule PowerCutScheduleObj = new PowerCutSchedule();

	@GET
	@Path("/")
	@Produces(MediaType.TEXT_HTML)
	public String readPowerCut() {
		return PowerCutScheduleObj.readPowerCut();
	}

	@POST
	@Path("/")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public String insertPowerCut(
			@FormParam("CutTime") String CutTime,
			@FormParam("CutDate") String CutDate,
			@FormParam("CutLocation") String CutLocation,
			@FormParam("CutTimeDuration") String CutTimeDuration) {
		String output = PowerCutScheduleObj.insertPowerCut(CutTime, CutDate, CutLocation, CutTimeDuration);
		return output;
	}
	
	@PUT
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)

	public String updatePowerCut(String powercutData) {
		// Convert the input string to a JSON object
		JsonObject PowerCutObject = new JsonParser().parse(powercutData).getAsJsonObject();

		// Read the values from the JSON object
		String CutID = PowerCutObject.get("CutID").getAsString();
		String CutTime = PowerCutObject.get("CutTime").getAsString();
		String CutDate = PowerCutObject.get("CutDate").getAsString();
		String CutLocation = PowerCutObject.get("CutLocation").getAsString();
		String CutTimeDuration = PowerCutObject.get("CutTimeDuration").getAsString();	
		String output = PowerCutScheduleObj.updatePowerCut(CutID, CutTime, CutDate, CutLocation, CutTimeDuration);
		return output;
	}
	
	@DELETE
	@Path("/")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public String deletePowerCut(String powercutData) {
		// Convert the input string to an XML document
		Document doc = Jsoup.parse(powercutData, "", Parser.xmlParser());

		// Read the value from the element
		String CutID = doc.select("CutID").text();
		String output = PowerCutScheduleObj.deletePowerCut(CutID);
		return output;
	}
}
