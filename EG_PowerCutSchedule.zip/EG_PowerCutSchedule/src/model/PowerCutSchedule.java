package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class PowerCutSchedule {

	private Connection connect() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Provide the correct details: DBServer/DBName, username, password
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/eg_project?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root", "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public String insertPowerCut(String CutTime, String CutDate, String CutLocation, String CutTimeDuration) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for inserting.";
			}
			// create a prepared statement
			String query = " insert into powercut(`CutTime`,`City_ID`,`CutDate`,`CutLocation`,`CutTimeDuration`)" + " values (?, ?, ?, ?, ?)";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			// binding values
			preparedStmt.setInt(1, 0);
			preparedStmt.setString(2, CutTime);
			preparedStmt.setString(3, CutDate);
			preparedStmt.setString(4, CutLocation);
			preparedStmt.setString(5, CutTimeDuration);

			// execute the statement
			preparedStmt.execute();
			con.close();
			output = "Inserted successfully";
		} catch (Exception e) {
			output = "Error while inserting the power cut time.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public String readPowerCut() {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for reading.";
			}
			// Prepare the html table to be displayed
			output = "<table border=\"1\"><tr><th>ID</th><th>Time</th><th>Date</th><th>Location</th><th>Time Duration</th></tr>";
			String query = "select * from powercut";
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = ((java.sql.Statement) stmt).executeQuery(query);
			// iterate through the rows in the result set
			while (rs.next()) {
				String CutID = Integer.toString(rs.getInt("CutID"));
				String CutTime = rs.getString("CutTime");
				String CutDate = rs.getString("CutDate");
				String CutLocation = rs.getString("CutLocation");
				String CutTimeDuration = rs.getString("CutTimeDuration");

				output += "<tr><td>" + CutID + "</td>";
				output += "<td>" + CutTime + "</td>";
				output += "<td>" + CutDate + "</td>";
				output += "<td>" + CutLocation + "</td>";
				output += "<td>" + CutTimeDuration + "</td>";
			}
			con.close();

			output += "</table>";
		} catch (Exception e) {
			output = "Error while reading the power cut time.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public String updatePowerCut(String CutID, String CutTime, String CutDate, String CutLocation, String CutTimeDuration) {
		String output = "";

		try {
			Connection con = connect();

			if (con == null) {
				return "Error while connecting to the database for updating.";
			}

			// create a prepared statement
			String query = "UPDATE powercut SET CutTime=?,CutDate=?,CutLocation=?,CutTimeDuration=? WHERE CutID=?";

			PreparedStatement preparedStmt = con.prepareStatement(query);

			// binding values
			preparedStmt.setString(1, CutTime);
			preparedStmt.setString(2, CutDate);
			preparedStmt.setString(3, CutLocation);
			preparedStmt.setString(4, CutTimeDuration);
			preparedStmt.setInt(5, Integer.parseInt(CutID));

			// execute the statement
			preparedStmt.execute();
			con.close();

			output = "Updated successfully";
		} catch (Exception e) {
			output = "Error while updating the power cut time.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public String deletePowerCut(String CutID) {

		String output = "";

		try {
			Connection con = connect();

			if (con == null) {
				return "Error while connecting to the database for deleting.";
			}

			// create a prepared statement
			String query = "delete from powercut where CutID=?";

			PreparedStatement preparedStmt = con.prepareStatement(query);

			// binding values
			preparedStmt.setInt(1, Integer.parseInt(CutID));

			// execute the statement
			preparedStmt.execute();
			con.close();

			output = "Deleted successfully";
		} catch (Exception e) {
			output = "Error while deleting the power cut time.";
			System.err.println(e.getMessage());
		}
		return output;
	}
}
