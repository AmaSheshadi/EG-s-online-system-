package com;
import java.sql.*;
public class Payment {

private Connection connect()
 {
 Connection con = null;
 try
 {
 Class.forName("com.mysql.jdbc.Driver");
 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/paf", "root", "");
 }
 catch (Exception e)
 {
 e.printStackTrace();
 }
 return con;
 }
public String readPayment()
 {
 String output = "";
 try
 {
 Connection con = connect();
 if (con == null)
 {
 return "Error while connecting to the database for reading.";
 }
 // Prepare the html table to be displayed
 output = "<table border=\"1\"><tr><th>Pay ID</th><th>Billing ID</th><th>Date</th><th>Account No</th><th>Total Amount</th><th>Update</th><th>Remove</th></tr>";
 String query = "select * from payment";
 Statement stmt = con.createStatement();
 ResultSet rs = stmt.executeQuery(query);
 // iterate through the rows in the result set
 while (rs.next())
 {
	 String paymentID = Integer.toString(rs.getInt("paymentID"));
		String billID = rs.getString("billID");
		String payDate = rs.getString("payDate");
		String accountNo = rs.getString("accountNo");
		String totalAmount = rs.getString("totalAmount");

 // Add into the html table
output += "<tr><td><input paymentID='hidPaymentIDUpdate' billID='hidPaymentIDUpdate' type='hidden' value='" + paymentID + "'>" + billID  + "</td>";
output += "<td>" + payDate + "</td>";
output += "<td>" + accountNo + "</td>";
output += "<td>" + totalAmount + "</td>";

 // buttons
output += "<td><input billID='btnUpdate'type='button' value='Update' class='btnUpdate btn btn-secondary'></td>"+ "<td><input billID='btnRemove' type='button' value='Remove'class='btnRemove btn btn-danger' data-id='"+ paymentID + "'>" + "</td></tr>";
 }
 con.close();
 // Complete the html table
 output += "</table>";
 }
 catch (Exception e)
 {
 output = "Error while reading the Payment";
 System.err.println(e.getMessage());
 }
 return output;
 }
public String insertPayment(String paymentID, String billID, String payDate, String accountNo, String totalAmount)
 {
 String output = "";
 try
 {
 Connection con = connect();
 if (con == null)
 {
 return "Error while connecting to the database for inserting.";
 }
 // create a prepared statement
 String query = " insert into payment(`paymentID`,`billID`,`payDate`,`accountNo`,`totalAmount`)" + " values (?, ?, ?, ?, ?)";
 PreparedStatement preparedStmt = con.prepareStatement(query);
 // binding values
 preparedStmt.setString(1, billID);
	preparedStmt.setString(2, payDate);
	preparedStmt.setString(3, accountNo);
	preparedStmt.setString(4, totalAmount);
	preparedStmt.setInt(5, Integer.parseInt(paymentID));

 // execute the statement
 preparedStmt.execute();
 con.close();
 String newPayment = readPayment();
 output = "{\"status\":\"success\", \"data\": \"" +newPayment + "\"}";
 }
 catch (Exception e)
 {
 output = "{\"status\":\"error\", \"data\": \"Error while inserting the payment.\"}";
 System.err.println(e.getMessage());
 }
 return output;
 }
public String updatePayment(String paymentID, String billID, String payDate, String accountNo, String totalAmount)
 {
 String output = "";
 try
 {
 Connection con = connect();
 if (con == null)
 {
 return "Error while connecting to the database for updating.";
 }
 // create a prepared statement
 String query = "UPDATE payment SET billID=?,payDate=?,accountNo=?,totalAmount=? WHERE paymentID=?";
	PreparedStatement preparedStmt = con.prepareStatement(query);
 // binding values
	preparedStmt.setString(1, billID);
	preparedStmt.setString(2, payDate);
	preparedStmt.setString(3, accountNo);
	preparedStmt.setString(4, totalAmount);
	preparedStmt.setInt(5, Integer.parseInt(paymentID));
 
 // execute the statement
 preparedStmt.execute();
 con.close();
 String newPayment = readPayment();
 output = "{\"status\":\"success\", \"data\": \"" + newPayment + "\"}";
 }
 catch (Exception e)
 {
 output = "{\"status\":\"error\", \"data\":\"Error while updating the item.\"}";
 System.err.println(e.getMessage());
 }
 return output;
 }
public String deletePayment(String paymentID)
 {
 String output = "";
 try
 {
 Connection con = connect();
 if (con == null)
 {
 return "Error while connecting to the database for deleting.";
 }
 // create a prepared statement
 String query = "delete from payment where paymentID=?";
	PreparedStatement preparedStmt = con.prepareStatement(query);

 // binding values
 preparedStmt.setInt(1, Integer.parseInt(paymentID));
 // execute the statement
 preparedStmt.execute();
 con.close();
 String newPayment = readPayment();
 output = "{\"status\":\"success\", \"data\": \"" + newPayment + "\"}";
 }
 catch (Exception e)
 {
 output = "{\"status\":\"error\", \"data\":\"Error while deleting the payment.\"}";
 System.err.println(e.getMessage());
 }
 return output;
 }
}