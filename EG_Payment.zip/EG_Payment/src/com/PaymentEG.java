package com;

import model.Payment;


import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
import org.jsoup.*;
import org.jsoup.parser.*;
import org.jsoup.nodes.Document;

@Path("/Payment")
public class PaymentEG {
	Payment PaymentObj = new Payment();

	@GET
	@Path("/")
	@Produces(MediaType.TEXT_HTML)
	public String readPayment() {
		return PaymentObj.readPayment();
	}

	
	@POST
	@Path("/")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public String insertPayment(
	@FormParam("billID") String billID,
	@FormParam("payDate") String payDate,
	@FormParam("accountNo") String accountNo,
	@FormParam("totalAmount") String totalAmount) {
	String output = PaymentObj.insertPayment(billID, payDate, accountNo, totalAmount);
	return output;
	}
	
	
	@PUT
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)

	public String updatePayment(String paymentData) {
		
		JsonObject paymentObject = new JsonParser().parse(paymentData).getAsJsonObject();
		// Read the values from the JSON object
		String paymentID = paymentObject.get("paymentID").getAsString();
		String billID = paymentObject.get("billID").getAsString();
		String payDate = paymentObject.get("payDate").getAsString();
		String accountNo = paymentObject.get("accountNo").getAsString();
		String totalAmount = paymentObject.get("totalAmount").getAsString();	
		String output = PaymentObj.updatePayment(paymentID, billID, payDate, accountNo, totalAmount);
		return output;
	}
	
	@DELETE
	@Path("/")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public String deletePayment(String paymentData) {
		
		Document doc = Jsoup.parse(paymentData, "", Parser.xmlParser());

		// Read the value from the element
		String paymentID = doc.select("paymentID").text();
		String output = PaymentObj.deletePayment(paymentID);
		return output;
		
	}
}
