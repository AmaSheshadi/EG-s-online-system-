package com;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
//For JSON
import com.google.gson.*;
//For XML 
import org.jsoup.*;
import org.jsoup.parser.*;
import org.jsoup.nodes.Document;

import model.Customer;

@Path("/Customer")
public class CustomerEG {
	Customer CustomerObj = new Customer();

	@GET
	@Path("/")
	@Produces(MediaType.TEXT_HTML)
	public String readCustomer() {
		return CustomerObj.readCustomer();
	}
	
	@POST
	@Path("/")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public String insertCustomer(
     @FormParam("firstname") String firstname,			
	 @FormParam("lastname") String lastname,
	 @FormParam("nic") String nic,
	 @FormParam("gender") String gender,
	 @FormParam("tele_no") String tele_no)
	{
	 String output = CustomerObj.insertCustomer(firstname, lastname, nic, gender, tele_no);
	return output;
	}
	
	@PUT
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String updateCustomer(String customerData)
	{
	//Convert the input string to a JSON object
	 JsonObject CustomerObject = new JsonParser().parse(customerData).getAsJsonObject();
	//Read the values from the JSON object
	 String ID = CustomerObject.get("ID").getAsString();
	 String firstname = CustomerObject.get("firstname").getAsString();
	 String lastname = CustomerObject.get("lastname").getAsString();
	 String nic = CustomerObject.get("nic").getAsString();
	 String gender = CustomerObject.get("gender").getAsString();
	 String tele_no = CustomerObject.get("tele_no").getAsString();
	 String output = CustomerObj.updateCustomer(ID, firstname, lastname, nic, gender, tele_no);
	return output;
	} 
	
	@DELETE
	@Path("/")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public String deleteCustomer(String customerData)
	{
	//Convert the input string to an XML document
	 Document doc = Jsoup.parse(customerData, "", Parser.xmlParser());

	//Read the value from the element 
	 String ID = doc.select("ID").text();
	 String output = CustomerObj.deleteCustomer(ID);
	return output;
	}
	
}
