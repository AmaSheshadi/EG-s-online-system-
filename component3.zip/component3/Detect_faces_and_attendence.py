import numpy as np
import face_recognition as fr
from cv2 import cv2
import pickle
from datetime import datetime
import time
from imutils import face_utils as face
from scipy.spatial import distance

encodingsFile: str = r"E:\\2022\\transport-3\\component3\\encoding.pickle"

video_capture = cv2.VideoCapture(0,cv2.CAP_DSHOW)

def MarkAttendence(name):
    with open('Attendence.csv', 'r+') as f:
        myDataList = f.readlines()
        nameList = []
        for line in myDataList:
            entry = line.split(',')
            nameList.append(entry[0])
        if name not in nameList:
            now = datetime.now()
            dt = now.strftime('%H:%M:%S')
            f.writelines(f'\n{name},{dt}')

# load the known faces and embeddings
print("[INFO] loading encodings...")
data = pickle.loads(open(encodingsFile, "rb").read())

known_face_encoding = data["encodings"]
known_face_names = data["names"]

fps_couter = 0
fps_to_display = 'initializing..'
fps_timer = time.time()

while True:
    ret, frame = video_capture.read()

    fps_couter+=1
    frame_new = cv2.flip(frame,1)
    if time.time()-fps_timer>=1.0:
        fps_to_display=fps_couter
        fps_timer=time.time()
        fps_couter=0
    cv2.putText(frame, "FPS :"+str(fps_to_display), (frame.shape[1]-100, frame.shape[0]-10),\
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

    # change the colors of frame to RGB
    rgb_frame = frame [:, :, ::-1] 

    face_location = fr.face_locations(rgb_frame)
    face_encodings = fr.face_encodings(rgb_frame)

    for (top, right, bottom, left), face_encoding in zip(face_location, face_encodings):
        matches = fr.compare_faces(known_face_encoding, face_encoding)

        name = "Unknown"
        face_distances = fr.face_distance(known_face_encoding, face_encoding)
        best_match_index = np.argmin(face_distances)
        
        #print(known_face_encoding[best_match_index])
        if matches[best_match_index]:
            name = known_face_names[best_match_index]
           # MarkAttendence(name)
        
        # frame over face. rectangle vertices, frame color, frame thickness
        cv2.rectangle(frame, (left, top), (right, bottom), (0,0,255), 2)
        # frame to display name
        cv2.rectangle(frame, (left, bottom -35), (right, bottom), (0, 0, 255), cv2.FILLED)
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(frame, name, (left + 6, bottom - 6), font, 0.5, (255, 255, 255), 1)

    gray = cv2.cvtColor(frame_new, cv2.COLOR_BGR2GRAY)

    cv2.imshow('Webcam_facerecognition', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()